var annotated_dup =
[
    [ "audio", "namespaceaudio.html", "namespaceaudio" ],
    [ "core", "namespacecore.html", "namespacecore" ],
    [ "graphics", "namespacegraphics.html", "namespacegraphics" ],
    [ "misc", "namespacemisc.html", "namespacemisc" ]
];