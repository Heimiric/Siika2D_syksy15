var searchData=
[
  ['removecomponent',['removeComponent',['../classmisc_1_1_game_object.html#a5de31428f322f3239e1fe6539af43a90',1,'misc::GameObject']]],
  ['removeref',['removeRef',['../classcore_1_1_memory_manager.html#ad23687ea2ded0e4c3b840cafd625126a',1,'core::MemoryManager']]],
  ['reset',['reset',['../classmisc_1_1_timer.html#a9020542d73357a4eef512eefaf57524b',1,'misc::Timer']]],
  ['resourcemanager',['ResourceManager',['../classcore_1_1_resource_manager.html#a3b32babd2e81909bbd90d7f2d566fadb',1,'core::ResourceManager']]],
  ['rotate',['rotate',['../classmisc_1_1_transform_component.html#a7141232cbbc4045aa70d46ce8477c87c',1,'misc::TransformComponent']]],
  ['run',['run',['../classcore_1_1_siika2_d.html#a5c8b7ce88d2885ca11b079d321e1959f',1,'core::Siika2D']]]
];
