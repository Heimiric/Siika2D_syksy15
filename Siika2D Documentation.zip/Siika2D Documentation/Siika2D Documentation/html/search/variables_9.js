var searchData=
[
  ['tobatch',['toBatch',['../classgraphics_1_1_sprite_manager.html#afb1c748cf6befa79fae925d5616158ff',1,'graphics::SpriteManager']]]
];
