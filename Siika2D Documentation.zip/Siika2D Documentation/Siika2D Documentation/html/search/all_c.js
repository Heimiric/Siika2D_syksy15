var searchData=
[
  ['new',['new',['../_memory_manager_8h.html#a1ac41480eb2e4aadd52252ee550b630a',1,'MemoryManager.h']]]
];
