var classgraphics_1_1_sprite =
[
    [ "Sprite", "classgraphics_1_1_sprite.html#ac6e3bfc4963257ef3835a8838b5a639b", null ],
    [ "Sprite", "classgraphics_1_1_sprite.html#a890aef9aaf6c69fa8d67173a5c815fea", null ],
    [ "Sprite", "classgraphics_1_1_sprite.html#a623318790bdeff79d02b116cf9cc419d", null ],
    [ "~Sprite", "classgraphics_1_1_sprite.html#a63d34a8c2cbd873aca83369682f3a01e", null ],
    [ "getColor", "classgraphics_1_1_sprite.html#ac4d29d96d94214d4675ad0b16d621816", null ],
    [ "getPosition", "classgraphics_1_1_sprite.html#a690590fcb4825f21f7bec99045d257c0", null ],
    [ "setColor", "classgraphics_1_1_sprite.html#a783e720c18515bc032f06149dd4480d3", null ],
    [ "setOrigin", "classgraphics_1_1_sprite.html#a9dba8693d9bd4211255badf7bab159de", null ],
    [ "setPosition", "classgraphics_1_1_sprite.html#a95a34fb46fb72a040a76a54fef11e1d5", null ],
    [ "setRotation", "classgraphics_1_1_sprite.html#a3c76fd3ab9c3505e55c1e48301e5a602", null ],
    [ "setSize", "classgraphics_1_1_sprite.html#af5a8b57be043e49ee844487c638104ab", null ],
    [ "setTexture", "classgraphics_1_1_sprite.html#aa6521b6ba4e8faf2127bc14b9e543b3d", null ],
    [ "setZ", "classgraphics_1_1_sprite.html#af907889d70f2f5c0886b3cb970b658b5", null ],
    [ "step", "classgraphics_1_1_sprite.html#a27169dde66b588811cd6165c5f26c67f", null ],
    [ "SpriteManager", "classgraphics_1_1_sprite.html#ac495e8b586409665102aa3021200d453", null ]
];