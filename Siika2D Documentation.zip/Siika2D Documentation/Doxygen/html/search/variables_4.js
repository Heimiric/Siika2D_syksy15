var searchData=
[
  ['file',['file',['../structcore_1_1_memory_manager_1_1new__ptr__list.html#a7fae9f80d3b8f621c3d047a0f68c6bfa',1,'core::MemoryManager::new_ptr_list']]],
  ['filedescriptor',['fileDescriptor',['../structcore_1_1_audio_data.html#a8775f8841a9a9d9ee6d5b57bb2d3d619',1,'core::AudioData']]]
];
