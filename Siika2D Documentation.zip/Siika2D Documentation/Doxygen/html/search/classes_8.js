var searchData=
[
  ['new_5fptr_5flist',['new_ptr_list',['../structcore_1_1_memory_manager_1_1new__ptr__list.html',1,'core::MemoryManager']]]
];
