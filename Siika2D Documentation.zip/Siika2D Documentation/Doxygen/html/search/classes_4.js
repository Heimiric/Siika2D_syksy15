var searchData=
[
  ['file',['File',['../classmisc_1_1_file.html',1,'misc']]],
  ['finger',['Finger',['../structmisc_1_1_finger.html',1,'misc']]]
];
