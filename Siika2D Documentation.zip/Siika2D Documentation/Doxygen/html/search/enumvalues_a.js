var searchData=
[
  ['seconds',['SECONDS',['../_timer_8h.html#ac8351ea77ae6a8faecc48c4a3766074fa70367ff8e866216e6a822a2c952abfc1',1,'Timer.h']]]
];
