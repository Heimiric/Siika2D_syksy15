var searchData=
[
  ['readfile',['readFile',['../classmisc_1_1_file.html#a7fda1dc767486e3ede955fecacc7d543',1,'misc::File']]],
  ['readtxtfile',['readTxtFile',['../classcore_1_1_siika2_d.html#a9add6a1545a057356fd2bac0748af90d',1,'core::Siika2D']]],
  ['reinitializeshaders',['ReinitializeShaders',['../classgraphics_1_1_shader_manager.html#a2643183dae3a29f04dc7255263a194db',1,'graphics::ShaderManager']]],
  ['removecomponent',['removeComponent',['../classmisc_1_1_game_object.html#a5de31428f322f3239e1fe6539af43a90',1,'misc::GameObject']]],
  ['removeref',['removeRef',['../classcore_1_1_memory_manager.html#ad23687ea2ded0e4c3b840cafd625126a',1,'core::MemoryManager']]],
  ['removesprite',['removeSprite',['../classgraphics_1_1_sprite_manager.html#af41e00b29e6a4c42479cd8e41a4bdb76',1,'graphics::SpriteManager']]],
  ['reset',['reset',['../classmisc_1_1_timer.html#a9020542d73357a4eef512eefaf57524b',1,'misc::Timer']]],
  ['resourcemanager',['ResourceManager',['../classcore_1_1_resource_manager.html#a3b32babd2e81909bbd90d7f2d566fadb',1,'core::ResourceManager']]],
  ['resume',['resume',['../classmisc_1_1_timer.html#a4ac55a73bb3431db9d4d2fd70ae9a2e8',1,'misc::Timer']]],
  ['rotate',['rotate',['../classgraphics_1_1_sprite.html#aa19898cfb22d0406816607fe0fc01bb9',1,'graphics::Sprite::rotate()'],['../classmisc_1_1_transform_component.html#a7141232cbbc4045aa70d46ce8477c87c',1,'misc::TransformComponent::rotate()']]],
  ['run',['run',['../classcore_1_1_siika2_d.html#a5c8b7ce88d2885ca11b079d321e1959f',1,'core::Siika2D']]]
];
