var searchData=
[
  ['nrefs',['nRefs',['../classcore_1_1_memory_manager.html#a4c55ba66e15916473921a82050d6cdfd',1,'core::MemoryManager']]]
];
