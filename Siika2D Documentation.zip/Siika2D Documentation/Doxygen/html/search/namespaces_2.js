var searchData=
[
  ['graphics',['graphics',['../namespacegraphics.html',1,'']]]
];
