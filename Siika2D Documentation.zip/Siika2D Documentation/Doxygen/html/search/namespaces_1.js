var searchData=
[
  ['core',['core',['../namespacecore.html',1,'']]]
];
