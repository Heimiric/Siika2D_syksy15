var searchData=
[
  ['camera_5fmovement',['CAMERA_MOVEMENT',['../namespacegraphics.html#a2ee0c47255615885417c605070323c7c',1,'graphics']]],
  ['color',['COLOR',['../namespacegraphics.html#a5acd35de041bd015ed25531e0fae2267',1,'graphics']]]
];
