var searchData=
[
  ['nanoseconds',['NANOSECONDS',['../_timer_8h.html#ac8351ea77ae6a8faecc48c4a3766074fa13886ffa6aa845119f9eb5eccec18bef',1,'Timer.h']]],
  ['not_5fset',['NOT_SET',['../namespacecore.html#ab2729f25d47d9fb93405127e217999dea1f6f2491c13fc499ed57a7c518d13e4e',1,'core']]]
];
