var searchData=
[
  ['debug_5fnew',['DEBUG_NEW',['../_memory_manager_8h.html#ae506a7a05c7311380f9160324fa2c047',1,'MemoryManager.h']]]
];
