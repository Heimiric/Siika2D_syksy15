var searchData=
[
  ['newscene',['newScene',['../classcore_1_1_scene_manager.html#ab312ee189d2e3c915b834f53679d9229',1,'core::SceneManager']]]
];
