var dir_ee1c17b98aff9f0e0bb6e69cd0279e91 =
[
    [ "ErrorHandler.cpp", "_error_handler_8cpp.html", null ],
    [ "ErrorHandler.h", "_error_handler_8h.html", "_error_handler_8h" ],
    [ "MemoryManager.h", "_memory_manager_8h.html", "_memory_manager_8h" ],
    [ "ResourceManager.cpp", "_resource_manager_8cpp.html", null ],
    [ "ResourceManager.h", "_resource_manager_8h.html", [
      [ "ImageData", "structcore_1_1_image_data.html", "structcore_1_1_image_data" ],
      [ "AudioData", "structcore_1_1_audio_data.html", "structcore_1_1_audio_data" ],
      [ "ResourceManager", "classcore_1_1_resource_manager.html", "classcore_1_1_resource_manager" ]
    ] ],
    [ "Siika2D.cpp", "_siika2_d_8cpp.html", null ],
    [ "Siika2D.h", "_siika2_d_8h.html", [
      [ "saved_state", "structcore_1_1saved__state.html", "structcore_1_1saved__state" ],
      [ "Siika2D", "classcore_1_1_siika2_d.html", "classcore_1_1_siika2_d" ]
    ] ]
];