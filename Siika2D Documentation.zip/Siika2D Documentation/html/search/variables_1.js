var searchData=
[
  ['angle',['angle',['../structcore_1_1saved__state.html#ad7da04fa63fb2a2b6fe988e32affb9c3',1,'core::saved_state']]]
];
