var searchData=
[
  ['width',['width',['../structcore_1_1_image_data.html#a84d8fa4f50525658a9bda14c45afdd9c',1,'core::ImageData']]]
];
