var searchData=
[
  ['red',['RED',['../namespacegraphics.html#a5acd35de041bd015ed25531e0fae2267aa702befc65c0250065ea5961c2d38e0e',1,'graphics']]],
  ['reset',['RESET',['../namespacegraphics.html#a2ee0c47255615885417c605070323c7ca0b6302ab62341ce98301b8e298cd175b',1,'graphics']]],
  ['right',['RIGHT',['../namespacegraphics.html#a2ee0c47255615885417c605070323c7caa3007edb9e4ff1151cc91ba6e46b6b28',1,'graphics']]]
];
