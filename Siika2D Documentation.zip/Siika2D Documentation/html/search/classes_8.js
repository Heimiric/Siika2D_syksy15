var searchData=
[
  ['resourcemanager',['ResourceManager',['../classcore_1_1_resource_manager.html',1,'core']]]
];
