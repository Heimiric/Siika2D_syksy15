var class_game_object =
[
    [ "GameObject", "class_game_object.html#a4dbc70ae9f20e17399a7b97a4c614fa5", null ],
    [ "~GameObject", "class_game_object.html#ab82dfdb656f9051c0587e6593b2dda97", null ],
    [ "getPosition", "class_game_object.html#a4a4042f7e6ccb8ed9a65e0d6a6b9b7f3", null ],
    [ "move", "class_game_object.html#a2c17fa1bccfaf811d5e362cdc6692c99", null ],
    [ "move", "class_game_object.html#aebed603ce671bd36197506c352ff21e6", null ]
];