var namespaces =
[
    [ "audio", "namespaceaudio.html", null ],
    [ "core", "namespacecore.html", null ],
    [ "graphics", "namespacegraphics.html", null ],
    [ "misc", "namespacemisc.html", null ]
];