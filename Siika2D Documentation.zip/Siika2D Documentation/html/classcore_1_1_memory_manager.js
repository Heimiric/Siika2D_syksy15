var classcore_1_1_memory_manager =
[
    [ "addRef", "classcore_1_1_memory_manager.html#aff258abf4f2caf75af7374fa8b447381", null ],
    [ "getCount", "classcore_1_1_memory_manager.html#af7a45afc340ecbaf1cb1255ccc91eb7d", null ],
    [ "removeRef", "classcore_1_1_memory_manager.html#ad23687ea2ded0e4c3b840cafd625126a", null ]
];