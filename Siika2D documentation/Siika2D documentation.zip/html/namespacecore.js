var namespacecore =
[
    [ "AndroidInterface", "classcore_1_1_android_interface.html", "classcore_1_1_android_interface" ],
    [ "AudioData", "structcore_1_1_audio_data.html", "structcore_1_1_audio_data" ],
    [ "ErrorHandler", "classcore_1_1_error_handler.html", null ],
    [ "ImageData", "structcore_1_1_image_data.html", "structcore_1_1_image_data" ],
    [ "MemoryManager", "classcore_1_1_memory_manager.html", "classcore_1_1_memory_manager" ],
    [ "ResourceManager", "classcore_1_1_resource_manager.html", "classcore_1_1_resource_manager" ],
    [ "saved_state", "structcore_1_1saved__state.html", "structcore_1_1saved__state" ],
    [ "Siika2D", "classcore_1_1_siika2_d.html", "classcore_1_1_siika2_d" ]
];