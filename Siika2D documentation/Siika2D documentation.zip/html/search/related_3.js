var searchData=
[
  ['textmanager',['TextManager',['../classgraphics_1_1_text.html#a72b63892b4338435846d7928babc8219',1,'graphics::Text']]]
];
