var searchData=
[
  ['color',['color',['../namespacegraphics.html#a0340b7a89bce6561797fd8edfed9e71daaf909d1399efe317319c3b1b80e0c0ff',1,'graphics']]]
];
