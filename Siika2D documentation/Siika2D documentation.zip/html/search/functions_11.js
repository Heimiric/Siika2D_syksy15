var searchData=
[
  ['wipecontext',['wipeContext',['../classgraphics_1_1_graphics_context.html#a00110ec9d8495d0591933f3f82c4ba51',1,'graphics::GraphicsContext']]]
];
