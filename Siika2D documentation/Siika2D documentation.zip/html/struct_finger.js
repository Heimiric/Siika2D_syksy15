var struct_finger =
[
    [ "_positionCurrent", "struct_finger.html#abb72f361307b16e9a81b4260a76e81c9", null ],
    [ "_positionEnd", "struct_finger.html#a6be5f9c8e0dedb9a2ae3f26cf1816fae", null ],
    [ "_positionStart", "struct_finger.html#a60af4256b3d46ca68ab72e2a7cba2e6e", null ]
];