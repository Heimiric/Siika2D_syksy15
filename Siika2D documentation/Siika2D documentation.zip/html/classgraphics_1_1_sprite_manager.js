var classgraphics_1_1_sprite_manager =
[
    [ "sprites_buffer", "structgraphics_1_1_sprite_manager_1_1sprites__buffer.html", "structgraphics_1_1_sprite_manager_1_1sprites__buffer" ],
    [ "SpriteManager", "classgraphics_1_1_sprite_manager.html#a73d1dc6d7087ee5f32f2f22760cfbd18", null ],
    [ "~SpriteManager", "classgraphics_1_1_sprite_manager.html#ae01a31b1c80f676604ba55c93b499e1f", null ],
    [ "batchSprites", "classgraphics_1_1_sprite_manager.html#a8d9c0e952107fe38f9657377b6eac205", null ],
    [ "compareSpriteZs", "classgraphics_1_1_sprite_manager.html#a9b8465b08579d5fa3098fa101478efb2", null ],
    [ "createSprite", "classgraphics_1_1_sprite_manager.html#afdc19f1f025ef15e18d6b51a432dfed4", null ],
    [ "createSprite", "classgraphics_1_1_sprite_manager.html#a9fe8aef8f816aabfbb8a8381a69135f3", null ],
    [ "createSprite", "classgraphics_1_1_sprite_manager.html#a8db197c9bd21ecc893021e35dee1494b", null ],
    [ "drawSprites", "classgraphics_1_1_sprite_manager.html#ae67fe3046c0869dc94ca977fab7a9ed3", null ],
    [ "spriteBatcher", "classgraphics_1_1_sprite_manager.html#a56c8c1be119d8507fd6102521efb979c", null ],
    [ "core::Siika2D", "classgraphics_1_1_sprite_manager.html#a7390b588209f3ddff65e7bec9eeed9be", null ],
    [ "_bufferManager", "classgraphics_1_1_sprite_manager.html#a84413a036ffed0670d2c9c5f5b985fd5", null ],
    [ "_shaderManager", "classgraphics_1_1_sprite_manager.html#a25d0fd5fcce8b156f3e988599b1aaaf3", null ],
    [ "_sprites", "classgraphics_1_1_sprite_manager.html#a1ee5e264f8f9062b1d2b235931377e18", null ],
    [ "toBatch", "classgraphics_1_1_sprite_manager.html#afb1c748cf6befa79fae925d5616158ff", null ]
];