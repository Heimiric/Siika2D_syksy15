var structcore_1_1saved__state =
[
    [ "angle", "structcore_1_1saved__state.html#ad7da04fa63fb2a2b6fe988e32affb9c3", null ],
    [ "x", "structcore_1_1saved__state.html#a6c625536ba2ab5f2444146f51977db89", null ],
    [ "y", "structcore_1_1saved__state.html#a17e2bb01bc55282e452a3d619f03c736", null ]
];