var structmisc_1_1_finger =
[
    [ "_positionCurrent", "structmisc_1_1_finger.html#af990c4a6afca0175c43b21611343ffe1", null ],
    [ "_positionEnd", "structmisc_1_1_finger.html#ab61304967db808b3181151f7536b60e6", null ],
    [ "_positionStart", "structmisc_1_1_finger.html#adc851310935b54678aa3d1dfca239825", null ]
];