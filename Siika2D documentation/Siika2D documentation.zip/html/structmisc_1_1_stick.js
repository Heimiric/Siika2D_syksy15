var structmisc_1_1_stick =
[
    [ "_pointingVector", "structmisc_1_1_stick.html#abcbb6989d582383399885d7048da570d", null ],
    [ "_rotation", "structmisc_1_1_stick.html#a1942ec4d18e35543d73dd04d767795c6", null ]
];