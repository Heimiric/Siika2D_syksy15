var classgraphics_1_1_color =
[
    [ "Color", "classgraphics_1_1_color.html#a34b79adaed5b59fabae0cd87eb9d20ca", null ],
    [ "Color", "classgraphics_1_1_color.html#a0a169e5ff7cc17872c3f21d652b02497", null ],
    [ "~Color", "classgraphics_1_1_color.html#a3cfce6c6821d3bf489e26074c55378c0", null ],
    [ "getA", "classgraphics_1_1_color.html#a0913c4bb2a39b4bc623236b44827098c", null ],
    [ "getB", "classgraphics_1_1_color.html#a6775ccf4a9cc16437f9a313c1353b045", null ],
    [ "getG", "classgraphics_1_1_color.html#a94a51d6145c4a5a2c763d795335fe2ee", null ],
    [ "getGLColor", "classgraphics_1_1_color.html#ace866d4093615318bff82465faec0456", null ],
    [ "getR", "classgraphics_1_1_color.html#a61bf78208a2d148482ace2a96d63329f", null ],
    [ "setAlpha", "classgraphics_1_1_color.html#a35a2b436b7e29863986b8c3c8a28edc3", null ],
    [ "setColor", "classgraphics_1_1_color.html#a834d30d339677f0ad3fd6168621e521c", null ],
    [ "setRGB", "classgraphics_1_1_color.html#a898db917bdfbfec1bdf33d228f2b817c", null ],
    [ "setRGBA", "classgraphics_1_1_color.html#ad910a5e5b015fce2b57850f6010d365b", null ]
];